#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "timer.h"
#include "stm32f10x_tim.h"

int main(void)
{
 u8 key;
 float a=1750, b=1600;        // int a=1750, b=1600;
 delay_init();		            //��ʱ������ʼ��	  
 LED_Init();			            //LED�˿ڳ�ʼ��
 TIM4_PWM_Init(19999,71);     ��//����Ƶ��PWMƵ��=72000/900=8KHz 
 TIM3_PWM_Init(19999,71);
 KEY_Init(); 
 	 
 TIM_SetCompare2(TIM4,a);
 TIM_SetCompare2(TIM3,b);
 
 while(1)
  {
		//TIM_SetCompare2(TIM4,1600);
		//TIM_SetCompare2(TIM3,2050);
	 key=KEY_Scan(0);
	 delay_ms(10);
	 
		switch(key)
    { 
		  case 1:	                           //��λ
			  
			  TIM_SetCompare2(TIM4,1800+190);	
			  TIM_SetCompare2(TIM3,1750-190);
		    delay_ms(100);
			break;
			
			case 2:			                       //��Ǧ�ʾ����ƶ�
		    
			  for(a=1800+190;a<=1950+190;a++)
			  {
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
				  delay_ms(10);
			  }
				
		    for(b=1750-190;b<=1850-190;b++)
				{
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
							delay_ms(10);
			  }
				
			  for(a=1950+190;a>=1670+190;a--)
				{
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
					delay_ms(10);
			  }
						
				for(b=1850-190;b>=1650-190;b--)
				{
  				TIM_SetCompare2(TIM4,a);
				  TIM_SetCompare2(TIM3,b);
					delay_ms(10);
			  }
						
				for(a=1670+190;a<=1950+190;a++)
				{
				  TIM_SetCompare2(TIM4,a);
				  TIM_SetCompare2(TIM3,b);
			    delay_ms(10);
			  }
		        
				for(b=1650-190;b<=1750-190;b++)
				{
				  TIM_SetCompare2(TIM4,a);
				  TIM_SetCompare2(TIM3,b);
					delay_ms(10);
			  }
					
				break;
         			
		  case 3:			                         //�ؽ��������ƶ�
			
		    for(a=1800+190;a<=1950+190;a++)
		    {
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
				  delay_ms(10);
		    }
		    for(b=1750-180;b<=1850-180;b++)
		    {
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
					delay_ms(10);
		    }
		    for(a=1950+190;a>=1670+190;a--)
		    {
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
					delay_ms(10);
		    }
        for(b=1850-180;b>=1650-180;b--)
		    {
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
					delay_ms(10);
			  }
	      for(a=1670+190;a<=1950+190;a++)
			  {
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
				  delay_ms(10);
			  }
	      for(b=1650-180;b<=1750-180;b++)
			  {
					TIM_SetCompare2(TIM4,a);
					TIM_SetCompare2(TIM3,b);
					delay_ms(10);
			  }
        
				break;	
				
    }			
  }
}

